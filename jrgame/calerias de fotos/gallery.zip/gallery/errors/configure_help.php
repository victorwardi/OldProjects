If you experience problems, you should seek help on the
<a href="http://gallery.sourceforge.net/help.php">Gallery Help Page</a>
