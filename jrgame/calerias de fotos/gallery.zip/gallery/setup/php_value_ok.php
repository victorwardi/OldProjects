<?php
// If we include this file it means that the php_value directive in .htaccess 
// was obeyed.
$GALLERY_PHP_VALUE_OK = 1;
?>
